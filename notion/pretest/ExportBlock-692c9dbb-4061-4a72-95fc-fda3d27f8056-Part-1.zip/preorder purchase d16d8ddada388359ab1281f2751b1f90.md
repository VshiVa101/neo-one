# preorder purchase

Status: 1st draft
Last edited: March 23, 2026 6:46 PM

### About asset

Provide a brief overview describing the asset.

### Supporting files

![Senza titolo-1.png](Senza_titolo-1%201.png)

[https://www.notion.so](https://www.notion.so)

[https://www.notion.so](https://www.notion.so)