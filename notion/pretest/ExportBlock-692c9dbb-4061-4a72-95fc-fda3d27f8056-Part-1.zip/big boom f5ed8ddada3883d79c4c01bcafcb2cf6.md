# big boom

Status: Not started
Last edited: March 23, 2026 6:46 PM

### About asset

Provide a brief overview describing the asset.

### Supporting files

![14.gif](14.gif)

[https://www.notion.so](https://www.notion.so)

[https://www.notion.so](https://www.notion.so)